# AI-Powered Meeting Assistant for Developers

🚀 **Transform meeting conversations into actionable development tasks automatically**

## 🎯 Project Overview

AI-Powered Meeting Assistant for Developers is an intelligent post-meeting processing tool designed specifically for software engineering teams. It bridges the gap between verbal discussions in meetings and actionable development tasks by leveraging Google Gemini 1.5 Flash's native multimodal audio understanding capabilities.

**Key Value Proposition:** Transform unstructured meeting recordings or videos into structured, executable development tasks that seamlessly integrate into engineers' daily workflows. Say goodbye to manual note-taking and forgotten action items.

## ✨ Core Features

### 🎵 Multimodal Input Processing
- **YouTube Integration**: Paste any YouTube video URL for instant processing
- **Local File Support**: Upload audio/video files (MP3, WAV, M4A) directly
- **Flexible Input**: Handle both streaming content and local recordings

### 🧠 Advanced AI Analysis
- **End-to-End Audio Understanding**: Direct audio processing via Gemini 1.5 Flash without traditional STT pipeline
- **Speaker Separation**: Automatic identification and labeling of different speakers ([Speaker 1], [Speaker 2], etc.)
- **Intent Recognition**: AI-powered extraction of actionable items from conversations
- **Entity Extraction**: Automatic identification of assignees, task titles, project names, and details

### ⚡ Automated Task Execution
- **Strategy Pattern Architecture**: Modular, pluggable automation strategies
- **GitHub Integration**: Automatically create issues and assign team members
- **Slack Integration**: Send smart reminders and notifications
- **Extensible Framework**: Easy addition of new automation workflows (Jira, Asana, Trello, etc.)

### 🔒 Enterprise-Grade Security
- **Encrypted Credential Storage**: User API keys are securely encrypted and stored
- **Environment Variable Management**: Sensitive data handled through secure configuration
- **User-Controlled Integrations**: Users provide their own API keys for maximum security

## 🏗️ Technology Stack

### Backend
- **Python 3.11+**
- **FastAPI** - High-performance web framework
- **Pydantic** - Data validation and serialization
- **SQLAlchemy** - Database ORM
- **Celery** - Background task processing
- **Redis** - Caching and message broker

### AI & Integrations
- **Google Gemini 1.5 Flash** - Core multimodal AI model
- **yt-dlp** - YouTube audio extraction
- **GitHub API** - Issue creation and management
- **Slack API** - Team notifications
- **cryptography** - Secure credential encryption

### Frontend
- **HTML5** - Modern web standards
- **Tailwind CSS** - Utility-first CSS framework
- **JavaScript (ES6+)** - Native browser APIs
- **WebSocket** - Real-time notifications

### DevOps
- **Docker** - Containerization
- **Docker Compose** - Multi-service orchestration
- **Uvicorn** - ASGI web server

## 🚀 Quick Start

### Prerequisites
- Python 3.11 or higher
- Docker and Docker Compose (optional)
- Google Gemini API key
- GitHub Personal Access Token
- Slack Bot Token (optional)

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/your-username/ai-meeting-assistant.git
cd ai-meeting-assistant
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Set up environment variables**
```bash
cp .env.example .env
# Edit .env with your API keys
```

4. **Run the application**
```bash
uvicorn app.main:app --reload
```

5. **Access the application**
Open your browser and navigate to `http://localhost:8000`

### Docker Setup

```bash
docker-compose up --build
```

## 📋 User Flow

1. **Input Audio**: Upload a local audio file or paste a YouTube URL
2. **AI Processing**: Gemini 1.5 Flash processes the audio and generates a transcript with speaker identification
3. **Intent Analysis**: The system analyzes the transcript to identify actionable items and extract relevant entities
4. **Task Creation**: Based on identified intents, the system automatically creates GitHub issues, sends Slack notifications, or performs other configured actions
5. **Real-time Feedback**: Users receive immediate feedback on completed actions with relevant links and details

## 🏢 Target Audience

- **Software Engineers** - Streamline meeting follow-ups
- **Development Teams** - Automate task creation and assignment
- **Project Managers** - Track action items automatically
- **Technical Leads** - Ensure nothing falls through the cracks
- **Remote Teams** - Bridge communication gaps effectively

## 🎨 Example Output

### Input
```
Meeting Audio: "Let's create a GitHub issue for refactoring the login module. 
John, can you handle that? Also, remind Sarah about the code review for PR #123."
```

### AI Analysis Result
```json
{
  "transcript": "[Speaker 1]: Let's create a GitHub issue for refactoring the login module. John, can you handle that? Also, remind Sarah about the code review for PR #123.",
  "intents": [
    {
      "intent": "CREATE_ISSUE",
      "entities": {
        "assignee_name": "John",
        "task_title": "Refactor login module",
        "project_or_repo": "main-project",
        "priority": "medium"
      }
    },
    {
      "intent": "SEND_SLACK_REMINDER",
      "entities": {
        "assignee_name": "Sarah",
        "reminder_content": "Code review for PR #123",
        "urgency": "normal"
      }
    }
  ]
}
```

### Automated Actions
- ✅ GitHub Issue #456 created: "Refactor login module" assigned to @john
- ✅ Slack message sent to @sarah: "Reminder: Code review for PR #123"

## 🔧 Configuration

### Supported Automation Strategies

| Strategy | Description | Required Credentials |
|----------|-------------|---------------------|
| `CREATE_ISSUE` | Create GitHub issues | GitHub PAT |
| `SEND_SLACK_REMINDER` | Send Slack notifications | Slack Bot Token |
| `CREATE_JIRA_TICKET` | Create Jira tickets | Jira API Token |
| `SCHEDULE_MEETING` | Google Calendar integration | Google API Key |
| `UPDATE_NOTION` | Update Notion pages | Notion Integration Token |

### Environment Variables

```bash
# Core Configuration
GEMINI_API_KEY=your_gemini_api_key
SECRET_KEY=your_secret_key_for_encryption
DATABASE_URL=sqlite:///./meeting_assistant.db

# Redis Configuration (for production)
REDIS_URL=redis://localhost:6379

# Optional Integrations
GITHUB_TOKEN=your_github_token
SLACK_BOT_TOKEN=your_slack_bot_token
JIRA_API_TOKEN=your_jira_token
```

## 📊 Market Impact

The AI meeting assistant market is experiencing explosive growth:
- **Market Size**: $1.2B in 2024 → $5.8B by 2033 (CAGR: 18.8%)
- **ROI Impact**: Meeting automation can boost productivity by up to 85%
- **Adoption Rate**: 75% of organizations using AI meeting tools by 2025

## 🚧 Roadmap

### Phase 1 (Current)
- [x] Basic audio transcription with speaker identification
- [x] GitHub issue creation
- [x] Slack notifications
- [x] Web interface

### Phase 2 (Q2 2025)
- [ ] Advanced intent recognition with custom training
- [ ] Multi-language support
- [ ] Jira and Asana integrations
- [ ] Meeting summary generation

### Phase 3 (Q3 2025)
- [ ] Real-time processing during live meetings
- [ ] Advanced analytics and insights
- [ ] Mobile application
- [ ] Enterprise SSO integration

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

### Development Setup

1. Fork the repository
2. Create a feature branch
3. Install development dependencies: `pip install -r requirements-dev.txt`
4. Run tests: `pytest`
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- **Documentation**: [Full docs available here](https://ai-meeting-assistant.readthedocs.io)
- **Issues**: [GitHub Issues](https://github.com/your-username/ai-meeting-assistant/issues)
- **Discord**: [Community Chat](https://discord.gg/ai-meeting-assistant)
- **Email**: support@ai-meeting-assistant.com

---

**Built with ❤️ by developers, for developers**

*Making meetings meaningful and actionable, one conversation at a time.*