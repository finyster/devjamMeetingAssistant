// AI Meeting Assistant Application Logic

class AIAssistantApp {
    constructor() {
        this.currentSection = 'hero';
        this.processingSteps = [
            { id: 1, text: '處理音頻檔案...', duration: 2000 },
            { id: 2, text: '轉換語音為文字...', duration: 3000 },
            { id: 3, text: '分析會議意圖...', duration: 4000 },
            { id: 4, text: '生成自動化建議...', duration: 2000 }
        ];
        
        this.demoData = {
            "demoScenarios": [
                {
                    "id": "standup",
                    "title": "Daily Standup Meeting",
                    "description": "團隊討論進度和阻礙",
                    "duration": "8 minutes",
                    "speakers": 3,
                    "transcript": "[說話者 1]: 好的，讓我們開始今天的standup。John，你昨天完成了什麼？\n[說話者 2]: 我完成了登入頁面的重構，但是遇到了一個API相容性的問題。我需要Mike幫忙看一下這個PR。\n[說話者 3]: 沒問題，我今天下午會review你的PR。另外，我昨天修復了支付模組的bug，今天計劃開始新的搜尋功能。\n[說話者 1]: 很好。John，你提到的API問題，我們應該建立一個issue來追蹤這個技術債務。\n[說話者 2]: 同意，我會建立一個GitHub issue並指派給後端團隊。還有，請提醒Sarah明天的code review session。",
                    "intents": [
                        {
                            "intent_type": "CREATE_ISSUE",
                            "confidence": 0.9,
                            "entities": {
                                "assignee_name": "後端團隊",
                                "task_title": "修復API相容性問題",
                                "project_or_repo": "main-app",
                                "details": "登入頁面重構過程中發現的API相容性問題，需要後端團隊協助解決",
                                "priority": "medium",
                                "labels": ["bug", "api", "compatibility"]
                            }
                        },
                        {
                            "intent_type": "ASSIGN_REVIEWER",
                            "confidence": 0.85,
                            "entities": {
                                "assignee_name": "Mike",
                                "task_title": "Review 登入頁面重構 PR",
                                "project_or_repo": "main-app",
                                "details": "Review John的登入頁面重構Pull Request"
                            }
                        },
                        {
                            "intent_type": "SEND_SLACK_REMINDER",
                            "confidence": 0.8,
                            "entities": {
                                "assignee_name": "Sarah",
                                "reminder_content": "明天的code review session",
                                "urgency": "normal"
                            }
                        }
                    ]
                },
                {
                    "id": "planning",
                    "title": "Sprint Planning Meeting",
                    "description": "團隊規劃即將到來的sprint功能",
                    "duration": "15 minutes",
                    "speakers": 4,
                    "transcript": "[說話者 1]: 我們來討論下一個sprint的規劃。首先是用戶認證系統的改進。\n[說話者 2]: 這個功能預估需要2個sprint。我建議我們先做OAuth整合，然後再做多因子認證。\n[說話者 3]: 同意。那我們建立兩個issue，一個是OAuth整合，指派給Alex，另一個是多因子認證，指派給Lisa。\n[說話者 4]: 還有，我們需要更新API文檔。我可以負責這個。\n[說話者 1]: 很好。另外，QA團隊需要提醒，下週三開始測試新功能。Jenny，你能負責通知他們嗎？",
                    "intents": [
                        {
                            "intent_type": "CREATE_ISSUE",
                            "confidence": 0.95,
                            "entities": {
                                "assignee_name": "Alex",
                                "task_title": "實作OAuth整合功能",
                                "project_or_repo": "auth-service",
                                "details": "為用戶認證系統添加OAuth整合支援，支援Google、GitHub等第三方登入",
                                "priority": "high",
                                "labels": ["feature", "oauth", "authentication"]
                            }
                        },
                        {
                            "intent_type": "CREATE_ISSUE",
                            "confidence": 0.95,
                            "entities": {
                                "assignee_name": "Lisa",
                                "task_title": "實作多因子認證",
                                "project_or_repo": "auth-service",
                                "details": "為用戶認證系統添加多因子認證功能，支援SMS和TOTP",
                                "priority": "high",
                                "labels": ["feature", "2fa", "security"]
                            }
                        },
                        {
                            "intent_type": "CREATE_ISSUE",
                            "confidence": 0.8,
                            "entities": {
                                "assignee_name": "說話者4",
                                "task_title": "更新API文檔",
                                "project_or_repo": "main-app",
                                "details": "更新API文檔以反映認證系統的新功能",
                                "priority": "medium",
                                "labels": ["documentation", "api"]
                            }
                        },
                        {
                            "intent_type": "SEND_SLACK_REMINDER",
                            "confidence": 0.9,
                            "entities": {
                                "assignee_name": "Jenny",
                                "reminder_content": "通知QA團隊下週三開始測試新的認證功能",
                                "urgency": "normal"
                            }
                        }
                    ]
                }
            ]
        };
        
        this.currentScenario = null;
        this.init();
    }

    init() {
        this.bindEvents();
        this.setupTheme();
        this.setupDragAndDrop();
    }

    bindEvents() {
        // Navigation events
        document.getElementById('startDemo').addEventListener('click', () => this.showSection('input'));
        document.getElementById('viewDemo').addEventListener('click', () => this.showDemoScenario('standup'));
        document.getElementById('backToInput').addEventListener('click', () => this.showSection('input'));
        
        // File upload events
        document.getElementById('fileInput').addEventListener('change', (e) => this.handleFileUpload(e));
        document.getElementById('uploadArea').addEventListener('click', () => document.getElementById('fileInput').click());
        
        // URL processing
        document.getElementById('processUrl').addEventListener('click', () => this.processYouTubeUrl());
        
        // Demo scenarios
        document.querySelectorAll('.scenario-card').forEach(card => {
            card.addEventListener('click', () => {
                const scenarioId = card.getAttribute('data-scenario');
                this.showDemoScenario(scenarioId);
            });
        });
        
        // Settings modal
        document.getElementById('settingsBtn').addEventListener('click', () => this.showSettings());
        document.getElementById('closeSettings').addEventListener('click', () => this.hideSettings());
        document.getElementById('saveSettings').addEventListener('click', () => this.saveSettings());
        document.getElementById('resetSettings').addEventListener('click', () => this.resetSettings());
        
        // Modal overlay close
        document.querySelector('.modal-overlay').addEventListener('click', () => this.hideSettings());
        
        // Theme toggle
        document.getElementById('themeToggle').addEventListener('click', () => this.toggleTheme());
        
        // Automation execution
        document.getElementById('executeAutomation').addEventListener('click', () => this.executeAutomation());
    }

    setupTheme() {
        const savedTheme = localStorage.getItem('theme') || 'light';
        this.setTheme(savedTheme);
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-color-scheme') || 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        this.setTheme(newTheme);
    }

    setTheme(theme) {
        document.documentElement.setAttribute('data-color-scheme', theme);
        localStorage.setItem('theme', theme);
        
        const themeToggle = document.getElementById('themeToggle');
        themeToggle.textContent = theme === 'light' ? '🌙 深色模式' : '☀️ 淺色模式';
    }

    setupDragAndDrop() {
        const uploadArea = document.getElementById('uploadArea');
        
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            uploadArea.addEventListener(eventName, () => {
                uploadArea.classList.add('dragover');
            });
        });

        ['dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, () => {
                uploadArea.classList.remove('dragover');
            });
        });

        uploadArea.addEventListener('drop', (e) => {
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.handleFileUpload({ target: { files } });
            }
        });
    }

    showSection(sectionName) {
        // Hide all sections
        ['heroSection', 'inputSection', 'processingSection', 'resultsSection'].forEach(id => {
            document.getElementById(id).classList.add('hidden');
        });
        
        // Show target section
        const targetSection = sectionName === 'hero' ? 'heroSection' : `${sectionName}Section`;
        document.getElementById(targetSection).classList.remove('hidden');
        document.getElementById(targetSection).classList.add('fade-in');
        
        this.currentSection = sectionName;
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        // Validate file type
        const allowedTypes = ['audio/mp3', 'audio/wav', 'audio/m4a', 'audio/ogg', 'audio/mpeg'];
        if (!allowedTypes.includes(file.type)) {
            alert('請上傳支援的音頻格式：MP3、WAV、M4A、OGG');
            return;
        }
        
        // Validate file size (100MB)
        if (file.size > 100 * 1024 * 1024) {
            alert('檔案大小不能超過 100MB');
            return;
        }
        
        this.processFile(file);
    }

    processYouTubeUrl() {
        const url = document.getElementById('youtubeUrl').value.trim();
        if (!url) {
            alert('請輸入YouTube連結');
            return;
        }
        
        // Validate YouTube URL
        const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+/;
        if (!youtubeRegex.test(url)) {
            alert('請輸入有效的YouTube連結');
            return;
        }
        
        this.processFile({ name: 'YouTube影片', type: 'youtube', url });
    }

    showDemoScenario(scenarioId) {
        const scenario = this.demoData.demoScenarios.find(s => s.id === scenarioId);
        if (!scenario) return;
        
        this.currentScenario = scenario;
        this.processFile({ name: `${scenario.title} (演示)`, type: 'demo' });
    }

    async processFile(file) {
        this.showSection('processing');
        
        let currentStep = 0;
        const progressBar = document.getElementById('progressBar');
        const statusElement = document.getElementById('processingStatus');
        
        for (const step of this.processingSteps) {
            // Update step status
            document.querySelectorAll('.step').forEach((stepEl, index) => {
                if (index < currentStep) {
                    stepEl.classList.add('completed');
                    stepEl.classList.remove('active');
                } else if (index === currentStep) {
                    stepEl.classList.add('active');
                } else {
                    stepEl.classList.remove('active', 'completed');
                }
            });
            
            // Update progress bar
            const progress = ((currentStep + 1) / this.processingSteps.length) * 100;
            progressBar.style.width = `${progress}%`;
            
            // Update status text
            statusElement.textContent = step.text;
            
            // Wait for step duration
            await new Promise(resolve => setTimeout(resolve, step.duration));
            
            currentStep++;
        }
        
        // Show results
        setTimeout(() => {
            this.showResults();
        }, 500);
    }

    showResults() {
        this.showSection('results');
        
        if (this.currentScenario) {
            this.displayTranscript(this.currentScenario.transcript);
            this.displayIntents(this.currentScenario.intents);
            this.displayAutomation(this.currentScenario.intents);
        } else {
            // Use default scenario for file uploads
            const defaultScenario = this.demoData.demoScenarios[0];
            this.displayTranscript(defaultScenario.transcript);
            this.displayIntents(defaultScenario.intents);
            this.displayAutomation(defaultScenario.intents);
        }
    }

    displayTranscript(transcript) {
        const transcriptElement = document.getElementById('transcript');
        const lines = transcript.split('\n');
        
        transcriptElement.innerHTML = lines.map(line => {
            if (line.includes('[說話者')) {
                const [speaker, ...content] = line.split(': ');
                return `<div class="speaker-line"><span class="speaker-name">${speaker}:</span> ${content.join(': ')}</div>`;
            }
            return `<div class="speaker-line">${line}</div>`;
        }).join('');
    }

    displayIntents(intents) {
        const intentsElement = document.getElementById('intentsList');
        
        intentsElement.innerHTML = intents.map(intent => {
            const confidencePercent = Math.round(intent.confidence * 100);
            const entities = Object.entries(intent.entities).map(([key, value]) => {
                return `<div class="entity-item">
                    <span class="entity-label">${this.formatEntityKey(key)}:</span>
                    <span class="entity-value">${Array.isArray(value) ? value.join(', ') : value}</span>
                </div>`;
            }).join('');
            
            return `<div class="intent-item">
                <div class="intent-header">
                    <span class="intent-type">${this.formatIntentType(intent.intent_type)}</span>
                    <span class="confidence-badge">${confidencePercent}% 信心度</span>
                </div>
                <div class="intent-entities">${entities}</div>
            </div>`;
        }).join('');
    }

    displayAutomation(intents) {
        const automationElement = document.getElementById('automationList');
        
        const automationItems = intents.map(intent => {
            let icon, title, description;
            
            switch (intent.intent_type) {
                case 'CREATE_ISSUE':
                    icon = '📋';
                    title = `創建 GitHub Issue: ${intent.entities.task_title}`;
                    description = `指派給 ${intent.entities.assignee_name} | 優先級: ${intent.entities.priority}`;
                    break;
                case 'ASSIGN_REVIEWER':
                    icon = '👤';
                    title = `指派審查者: ${intent.entities.task_title}`;
                    description = `指派給 ${intent.entities.assignee_name}`;
                    break;
                case 'SEND_SLACK_REMINDER':
                    icon = '💬';
                    title = `發送 Slack 提醒`;
                    description = `給 ${intent.entities.assignee_name}: ${intent.entities.reminder_content}`;
                    break;
                default:
                    icon = '⚡';
                    title = intent.intent_type;
                    description = '自動化操作';
            }
            
            return `<div class="automation-item">
                <div class="automation-icon">${icon}</div>
                <div class="automation-content">
                    <div class="automation-title">${title}</div>
                    <div class="automation-description">${description}</div>
                </div>
                <div class="automation-status pending">待執行</div>
            </div>`;
        }).join('');
        
        automationElement.innerHTML = automationItems;
    }

    formatIntentType(type) {
        const typeMap = {
            'CREATE_ISSUE': '創建問題',
            'ASSIGN_REVIEWER': '指派審查者',
            'SEND_SLACK_REMINDER': '發送提醒'
        };
        return typeMap[type] || type;
    }

    formatEntityKey(key) {
        const keyMap = {
            'assignee_name': '指派人',
            'task_title': '任務標題',
            'project_or_repo': '專案/儲存庫',
            'details': '詳細描述',
            'priority': '優先級',
            'labels': '標籤',
            'reminder_content': '提醒內容',
            'urgency': '緊急程度'
        };
        return keyMap[key] || key;
    }

    async executeAutomation() {
        const automationItems = document.querySelectorAll('.automation-item');
        
        for (let i = 0; i < automationItems.length; i++) {
            const item = automationItems[i];
            const statusElement = item.querySelector('.automation-status');
            
            // Update status to processing
            statusElement.textContent = '執行中...';
            statusElement.className = 'automation-status pending';
            
            // Simulate processing time
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Update to success
            statusElement.textContent = '已完成';
            statusElement.className = 'automation-status success';
        }
        
        // Show success toast
        this.showToast('自動化操作執行成功！');
        
        // Update button text
        document.getElementById('executeAutomation').textContent = '✅ 已執行完成';
        document.getElementById('executeAutomation').disabled = true;
    }

    showSettings() {
        document.getElementById('settingsModal').classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }

    hideSettings() {
        document.getElementById('settingsModal').classList.add('hidden');
        document.body.style.overflow = '';
    }

    saveSettings() {
        // Simulate saving settings
        this.showToast('設定已儲存');
        this.hideSettings();
    }

    resetSettings() {
        // Reset all form inputs in settings
        const settingsModal = document.getElementById('settingsModal');
        const inputs = settingsModal.querySelectorAll('input[type="password"]');
        inputs.forEach(input => input.value = '');
        
        const checkboxes = settingsModal.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            checkbox.checked = checkbox.hasAttribute('checked');
        });
        
        this.showToast('設定已重置');
    }

    showToast(message) {
        const toast = document.getElementById('successMessage');
        const textElement = toast.querySelector('.toast-text');
        
        textElement.textContent = message;
        toast.classList.remove('hidden');
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 300);
        }, 3000);
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AIAssistantApp();
});